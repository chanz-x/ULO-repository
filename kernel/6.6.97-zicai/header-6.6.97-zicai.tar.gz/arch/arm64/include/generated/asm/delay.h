#include <asm-generic/delay.h>
